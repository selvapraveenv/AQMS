
import { Brand, Query, TeamMember, Channel, Category, Priority, Status, Team, HistoryEntry } from '../types';

export const BRANDS: Brand[] = [
  { name: 'TechNova', channels: [Channel.EMAIL, Channel.INSTAGRAM, Channel.CHAT], logo: 'cpu' },
  { name: 'FashionHive', channels: [Channel.FACEBOOK, Channel.EMAIL], logo: 'tag' },
  { name: 'FoodKart', channels: [Channel.CHAT, Channel.FORUM], logo: 'shopping-cart' },
  { name: 'EcoWorld', channels: [Channel.EMAIL, Channel.FORUM], logo: 'leaf' },
];

const assignPriorityAndTeam = (msg: string): { priority: Priority; team: Team } => {
  const lowerMsg = msg.toLowerCase();
  if (/\b(angry|not received|refund now|urgent|complaint|legal)\b/.test(lowerMsg)) {
    return { priority: Priority.HIGH, team: Team.CRISIS };
  }
  if (/\b(issue|problem|can't|cannot|not working|broken)\b/.test(lowerMsg)) {
    return { priority: Priority.MEDIUM, team: Team.SUPPORT };
  }
  return { priority: Priority.LOW, team: Team.GENERAL };
};

const initialQueries: Omit<Query, 'priority' | 'team' | 'history'>[] = [
  { id: 'MSG001', sender: 'Rahul Verma', senderAvatar: 'https://picsum.photos/seed/rahul/40/40', msg: 'My order hasn’t arrived and support is not responding! This is an urgent complaint.', channel: Channel.EMAIL, category: Category.COMPLAINT, status: Status.NEW, timestamp: '2024-07-28T10:30:00Z' },
  { id: 'MSG002', sender: 'Emily S', senderAvatar: 'https://picsum.photos/seed/emily/40/40', msg: 'Hey, I want to know if COD is available for my location?', channel: Channel.INSTAGRAM, category: Category.QUESTION, status: Status.ASSIGNED, timestamp: '2024-07-28T11:05:00Z' },
  { id: 'MSG003', sender: 'David Chen', senderAvatar: 'https://picsum.photos/seed/david/40/40', msg: 'Your new app update is fantastic! Just some minor feedback on the UI.', channel: Channel.FORUM, category: Category.FEEDBACK, status: Status.RESOLVED, timestamp: '2024-07-28T09:45:00Z' },
  { id: 'MSG004', sender: 'Sophia Loren', senderAvatar: 'https://picsum.photos/seed/sophia/40/40', msg: 'I have a problem with my account login. It says "invalid credentials" but I am sure they are correct.', channel: Channel.CHAT, category: Category.BUG_REPORT, status: Status.IN_PROGRESS, timestamp: '2024-07-28T12:00:00Z' },
  { id: 'MSG005', sender: 'John Doe', senderAvatar: 'https://picsum.photos/seed/john/40/40', msg: 'I would like to request a feature to export my data as a CSV file.', channel: Channel.EMAIL, category: Category.REQUEST, status: Status.ASSIGNED, timestamp: '2024-07-27T18:20:00Z' },
  { id: 'MSG006', sender: 'Anonymous', senderAvatar: 'https://picsum.photos/seed/anon/40/40', msg: 'CLICK HERE TO WIN A FREE IPHONE!!!', channel: Channel.EMAIL, category: Category.SPAM, status: Status.CLOSED, timestamp: '2024-07-27T15:10:00Z' },
  { id: 'MSG007', sender: 'Maria Garcia', senderAvatar: 'https://picsum.photos/seed/maria/40/40', msg: 'The payment gateway is not working. I can\'t complete my purchase.', channel: Channel.FACEBOOK, category: Category.COMPLAINT, status: Status.NEW, timestamp: '2024-07-28T13:15:00Z' },
  { id: 'MSG008', sender: 'Alex Johnson', senderAvatar: 'https://picsum.photos/seed/alex/40/40', msg: 'How do I track my order?', channel: Channel.CHAT, category: Category.QUESTION, status: Status.RESOLVED, timestamp: '2024-07-26T14:00:00Z' },
  { id: 'MSG009', sender: 'Ben Carter', senderAvatar: 'https://picsum.photos/seed/ben/40/40', msg: 'Received a broken item. I need a refund now!', channel: Channel.INSTAGRAM, category: Category.COMPLAINT, status: Status.NEW, timestamp: '2024-07-28T13:30:00Z' },
  { id: 'MSG010', sender: 'Chloe Davis', senderAvatar: 'https://picsum.photos/seed/chloe/40/40', msg: 'Your support team is amazing. They resolved my issue in minutes!', channel: Channel.EMAIL, category: Category.FEEDBACK, status: Status.CLOSED, timestamp: '2024-07-25T11:00:00Z' },
  { id: 'MSG011', sender: 'Daniel Evans', senderAvatar: 'https://picsum.photos/seed/daniel/40/40', msg: 'The app crashes every time I try to open the settings page. This is a major issue.', channel: Channel.FORUM, category: Category.BUG_REPORT, status: Status.IN_PROGRESS, timestamp: '2024-07-28T08:00:00Z' },
  { id: 'MSG012', sender: 'Eva Wilson', senderAvatar: 'https://picsum.photos/seed/eva/40/40', msg: 'Can I change my delivery address after placing the order?', channel: Channel.CHAT, category: Category.QUESTION, status: Status.ASSIGNED, timestamp: '2024-07-28T14:00:00Z' },
  { id: 'MSG013', sender: 'Frank Green', senderAvatar: 'https://picsum.photos/seed/frank/40/40', msg: 'There is a legal issue with one of your product descriptions, it is misleading.', channel: Channel.EMAIL, category: Category.COMPLAINT, status: Status.NEW, timestamp: '2024-07-28T14:10:00Z' },
  { id: 'MSG014', sender: 'Grace Hall', senderAvatar: 'https://picsum.photos/seed/grace/40/40', msg: 'Just a quick query about your return policy.', channel: Channel.FACEBOOK, category: Category.QUESTION, status: Status.RESOLVED, timestamp: '2024-07-27T10:00:00Z' },
  { id: 'MSG015', sender: 'Henry King', senderAvatar: 'https://picsum.photos/seed/henry/40/40', msg: 'The latest update has a problem, the main dashboard is not loading.', channel: Channel.FORUM, category: Category.BUG_REPORT, status: Status.ASSIGNED, timestamp: '2024-07-28T14:15:00Z' },
  { id: 'MSG016', sender: 'Isla Wright', senderAvatar: 'https://picsum.photos/seed/isla/40/40', msg: 'Can you please add a dark mode to the app? It would be a great request.', channel: Channel.INSTAGRAM, category: Category.REQUEST, status: Status.IN_PROGRESS, timestamp: '2024-07-26T20:00:00Z' },
  { id: 'MSG017', sender: 'Jack Turner', senderAvatar: 'https://picsum.photos/seed/jack/40/40', msg: 'My account was charged twice. This is an urgent financial problem!', channel: Channel.CHAT, category: Category.COMPLAINT, status: Status.NEW, timestamp: '2024-07-28T14:25:00Z' },
  { id: 'MSG018', sender: 'Lily Baker', senderAvatar: 'https://picsum.photos/seed/lily/40/40', msg: 'Your packaging is so eco-friendly! Great feedback for your team.', channel: Channel.EMAIL, category: Category.FEEDBACK, status: Status.CLOSED, timestamp: '2024-07-24T16:00:00Z' },
  { id: 'MSG019', sender: 'Max Clark', senderAvatar: 'https://picsum.photos/seed/max/40/40', msg: 'How to use the new analytics feature?', channel: Channel.FORUM, category: Category.QUESTION, status: Status.RESOLVED, timestamp: '2024-07-27T13:00:00Z' },
  { id: 'MSG020', sender: 'Nora Evans', senderAvatar: 'https://picsum.photos/seed/nora/40/40', msg: 'The link you sent me is not working.', channel: Channel.EMAIL, category: Category.BUG_REPORT, status: Status.IN_PROGRESS, timestamp: '2024-07-28T14:45:00Z' },
];

export const TEAMS_MEMBERS: TeamMember[] = [
  ...Array.from({ length: 10 }, (_, i) => ({ name: `Crisis Agent ${i + 1}`, team: Team.CRISIS })),
  ...Array.from({ length: 25 }, (_, i) => ({ name: `Support Agent ${i + 1}`, team: Team.SUPPORT })),
  ...Array.from({ length: 15 }, (_, i) => ({ name: `General Agent ${i + 1}`, team: Team.GENERAL })),
];

export const getInitialQueries = (): Query[] => {
  return initialQueries.map(q => {
    const { priority, team } = assignPriorityAndTeam(q.msg);
    const creationTime = new Date(q.timestamp);
    
    // FIX: Explicitly type history array to allow for objects with optional 'agent' property.
    const history: HistoryEntry[] = [
      { timestamp: creationTime.toISOString(), action: 'Query Created' },
      { timestamp: new Date(creationTime.getTime() + 10000).toISOString(), action: `Auto-tagged as ${q.category}`},
      { timestamp: new Date(creationTime.getTime() + 20000).toISOString(), action: `Priority set to ${priority}`},
      { timestamp: new Date(creationTime.getTime() + 30000).toISOString(), action: `Assigned to ${team}`},
    ];

    if(q.status !== Status.NEW) {
      history.push({ timestamp: new Date(creationTime.getTime() + 600000).toISOString(), action: 'Viewed by Agent', agent: 'Agent A'});
    }

    return { ...q, priority, team, history };
  });
};
