
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("Gemini API key not found. Please set the API_KEY environment variable.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export const summarizeWithPro = async (text: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: `Summarize the following customer query in one sentence: "${text}"`,
    });
    return response.text;
  } catch (error) {
    console.error("Error summarizing with Pro:", error);
    return "Could not summarize the query.";
  }
};

export const draftReplyWithLite = async (text: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      // FIX: Updated model name to 'gemini-flash-lite-latest' per Gemini API guidelines.
      model: 'gemini-flash-lite-latest',
      contents: `Draft a polite and helpful customer service reply for the following query. Be concise. Query: "${text}"`,
    });
    return response.text;
  } catch (error) {
    console.error("Error drafting reply with Lite:", error);
    return "Could not draft a reply.";
  }
};

export const searchWithGrounding = async (text: string): Promise<{ text: string, groundingChunks: any[] }> => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: `Based on the latest information from Google Search, answer the following customer query: "${text}"`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
    return { text: response.text, groundingChunks };
  } catch (error) {
    console.error("Error searching with grounding:", error);
    return { text: "Could not perform search.", groundingChunks: [] };
  }
};

export const deepDiveWithPro = async (text: string): Promise<string> => {
  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: `Perform a deep, complex analysis of this customer issue. Identify the root cause, potential solutions, and sentiment. Query: "${text}"`,
      config: {
        thinkingConfig: { thinkingBudget: 32768 },
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error with deep dive analysis:", error);
    return "Could not perform deep dive analysis.";
  }
};

export const recategorizeWithAI = async (text: string): Promise<{ category: string }> => {
    try {
        const response: GenerateContentResponse = await ai.models.generateContent({
            // FIX: Updated model name to 'gemini-flash-lite-latest' per Gemini API guidelines.
            model: "gemini-flash-lite-latest",
            contents: `Categorize the following customer message into one of these categories: Question, Complaint, Request, Feedback, Bug Report, Spam. Message: "${text}"`,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        category: {
                            type: Type.STRING,
                            description: 'The determined category for the message.'
                        }
                    }
                }
            }
        });
        const jsonStr = response.text.trim();
        return JSON.parse(jsonStr);
    } catch (error) {
        console.error("Error re-categorizing with AI:", error);
        return { category: "Question" }; // fallback
    }
};