import React, { useState } from 'react';
import Icon from '../components/Icon';

interface LoginPageProps {
  onLogin: () => void;
}

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [email, setEmail] = useState('user@example.com');
  const [password, setPassword] = useState('');
  const [emailError, setEmailError] = useState('');
  const [strength, setStrength] = useState({ score: 0, label: '', color: '' });

  const validateEmail = (email: string) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email) {
      setEmailError('Email is required.');
      return false;
    } else if (!regex.test(email)) {
      setEmailError('Please enter a valid email address.');
      return false;
    }
    setEmailError('');
    return true;
  };

  const checkPasswordStrength = (pass: string) => {
    let score = 0;
    if (!pass) {
      setStrength({ score: 0, label: '', color: '' });
      return;
    };
    if (pass.length > 7) score++; // length
    if (/[a-z]/.test(pass) && /[A-Z]/.test(pass)) score++; // upper & lower case
    if (/[0-9]/.test(pass)) score++; // numbers
    if (/[^a-zA-Z0-9]/.test(pass)) score++; // special chars
    
    let label = '';
    let color = '';
    
    switch (score) {
        case 1:
            label = 'Weak';
            color = 'bg-danger';
            break;
        case 2:
            label = 'Medium';
            color = 'bg-warning';
            break;
        case 3:
            label = 'Strong';
            color = 'bg-success';
            break;
        case 4:
            label = 'Very Strong';
            color = 'bg-green-500'; 
            break;
        default:
            label = 'Weak';
            color = 'bg-danger';
    }
    setStrength({ score, label, color });
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newEmail = e.target.value;
    setEmail(newEmail);
    validateEmail(newEmail);
  };
  
  const handlePasswordChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newPassword = e.target.value;
    setPassword(newPassword);
    checkPasswordStrength(newPassword);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateEmail(email)) {
        onLogin();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-light dark:bg-gray-900">
      <div className="w-full max-w-md p-8 space-y-6 bg-white dark:bg-gray-800 rounded-xl shadow-lg">
        <div className="text-center">
          <h1 className="text-3xl font-bold text-gray-800 dark:text-white">
            Welcome Back!
          </h1>
          <p className="mt-2 text-sm text-gray-600 dark:text-gray-400">
            Sign in to continue to AQMS.
          </p>
        </div>
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          <div className="rounded-md shadow-sm space-y-4">
            <div>
              <label htmlFor="email-address" className="text-sm font-medium text-gray-700 dark:text-gray-300">Email address</label>
              <input
                id="email-address"
                name="email"
                type="email"
                autoComplete="email"
                required
                className={`mt-1 appearance-none relative block w-full px-3 py-2 border placeholder-gray-400 dark:placeholder-gray-400 text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700 rounded-md focus:outline-none focus:ring-primary focus:border-primary sm:text-sm ${emailError ? 'border-danger' : 'border-gray-300 dark:border-gray-600'}`}
                placeholder="user@example.com"
                value={email}
                onChange={handleEmailChange}
              />
              {emailError && <p className="mt-1 text-xs text-danger">{emailError}</p>}
            </div>
            <div>
              <label htmlFor="password-address" className="text-sm font-medium text-gray-700 dark:text-gray-300">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                className="mt-1 appearance-none relative block w-full px-3 py-2 border border-gray-300 dark:border-gray-600 placeholder-gray-400 dark:placeholder-gray-400 text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700 rounded-md focus:outline-none focus:ring-primary focus:border-primary sm:text-sm"
                placeholder="Password"
                value={password}
                onChange={handlePasswordChange}
              />
               {password.length > 0 && (
                 <div className="mt-2">
                    <div className="flex space-x-1">
                        <div className={`h-1.5 rounded-full w-1/4 ${strength.score >= 1 ? strength.color : 'bg-gray-200 dark:bg-gray-600'}`}></div>
                        <div className={`h-1.5 rounded-full w-1/4 ${strength.score >= 2 ? strength.color : 'bg-gray-200 dark:bg-gray-600'}`}></div>
                        <div className={`h-1.5 rounded-full w-1/4 ${strength.score >= 3 ? strength.color : 'bg-gray-200 dark:bg-gray-600'}`}></div>
                        <div className={`h-1.5 rounded-full w-1/4 ${strength.score >= 4 ? strength.color : 'bg-gray-200 dark:bg-gray-600'}`}></div>
                    </div>
                    <p className={`mt-1 text-xs font-medium ${strength.color.replace('bg-','text-')}`}>{strength.label}</p>
                 </div>
               )}
            </div>
          </div>
          <div>
            <button
              type="submit"
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-primary hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Sign in
            </button>
          </div>
        </form>

        <div className="relative my-4">
            <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-300 dark:border-gray-600"></div>
            </div>
            <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white dark:bg-gray-800 text-gray-500 dark:text-gray-400">Or continue with</span>
            </div>
        </div>
        <div>
            <button
                type="button"
                onClick={onLogin}
                className="w-full inline-flex items-center justify-center py-2 px-4 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm bg-white dark:bg-gray-700 text-sm font-medium text-gray-700 dark:text-gray-200 hover:bg-gray-50 dark:hover:bg-gray-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
                <Icon name="google-logo" className="w-5 h-5 mr-3" />
                Sign in with Google
            </button>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
