import React, { useMemo } from 'react';
import { useQueries } from '../context/QueryContext';
import { TEAMS_MEMBERS } from '../data/mockData';
import { Team, Priority } from '../types';
import Icon from '../components/Icon';

const TeamCard: React.FC<{ team: Team, members: number, workload: Record<Priority, number>, total: number }> = ({ team, members, workload, total }) => (
    <div className="bg-white dark:bg-dark p-6 rounded-lg shadow">
        <div className="flex items-center mb-4">
            <div className="p-3 rounded-full bg-primary/10 text-primary mr-4">
                <Icon name="users" className="w-6 h-6" />
            </div>
            <div>
                <h3 className="text-xl font-bold text-gray-800 dark:text-white">{team}</h3>
                <p className="text-sm text-gray-500 dark:text-gray-400">{members} members</p>
            </div>
        </div>
        <div className="space-y-2 text-sm">
            <div className="flex justify-between">
                <span className="text-gray-600 dark:text-gray-400">Total Assigned Queries</span>
                <span className="font-bold text-gray-800 dark:text-white">{total}</span>
            </div>
             <hr className="dark:border-gray-700/50 my-2" />
            <div className="flex justify-between items-center">
                <span className="font-medium text-danger">High Priority</span>
                <span className="font-semibold text-danger">{workload[Priority.HIGH]}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="font-medium text-warning">Medium Priority</span>
                <span className="font-semibold text-warning">{workload[Priority.MEDIUM]}</span>
            </div>
            <div className="flex justify-between items-center">
                <span className="font-medium text-gray-500 dark:text-gray-400">Low Priority</span>
                <span className="font-semibold text-gray-600 dark:text-gray-300">{workload[Priority.LOW]}</span>
            </div>
        </div>
    </div>
);

const TeamsPage: React.FC = () => {
    const { queries } = useQueries();

    const teamData = useMemo(() => {
        const teams = Object.values(Team);
        return teams.map(team => {
            const teamMembersCount = TEAMS_MEMBERS.filter(m => m.team === team).length;
            const teamQueries = queries.filter(q => q.team === team);
            
            const workload = teamQueries.reduce((acc, q) => {
                acc[q.priority] = (acc[q.priority] || 0) + 1;
                return acc;
            }, { [Priority.HIGH]: 0, [Priority.MEDIUM]: 0, [Priority.LOW]: 0 });

            return {
                team,
                members: teamMembersCount,
                workload,
                total: teamQueries.length,
            };
        });
    }, [queries]);

    return (
        <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">Team Overview & Workload</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {teamData.map(data => (
                    <TeamCard key={data.team} {...data} />
                ))}
            </div>
             <div className="bg-white dark:bg-dark rounded-lg shadow mt-8">
                <div className="p-4 border-b dark:border-gray-700/50">
                    <h3 className="text-lg font-bold text-gray-800 dark:text-white">All Members</h3>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left text-gray-600 dark:text-gray-400">
                        <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700/50 dark:text-gray-400">
                            <tr>
                                <th scope="col" className="px-6 py-3">Member Name</th>
                                <th scope="col" className="px-6 py-3">Team</th>
                            </tr>
                        </thead>
                        <tbody>
                            {TEAMS_MEMBERS.map((member, index) => (
                                <tr key={index} className="bg-white dark:bg-dark border-b dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                                    <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">{member.name}</td>
                                    <td className="px-6 py-4">{member.team}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default TeamsPage;