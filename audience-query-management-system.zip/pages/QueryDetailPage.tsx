import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQueries } from '../context/QueryContext';
import { Status, Query, GroundingChunk, Category, Priority } from '../types';
import Icon from '../components/Icon';
import { summarizeWithPro, draftReplyWithLite, searchWithGrounding, deepDiveWithPro, recategorizeWithAI } from '../services/geminiService';

const GeminiActionCard: React.FC<{
  title: string;
  description: string;
  icon: string;
  buttonText: string;
  action: () => void;
  isLoading: boolean;
}> = ({ title, description, icon, buttonText, action, isLoading }) => (
  <div className="bg-light dark:bg-gray-700/50 p-4 rounded-lg text-center">
    <Icon name={icon} className="w-8 h-8 mx-auto mb-2 text-primary" />
    <h4 className="font-bold text-gray-800 dark:text-white">{title}</h4>
    <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">{description}</p>
    <button
      onClick={action}
      disabled={isLoading}
      className="w-full text-sm font-semibold py-2 px-4 rounded-lg bg-primary text-white hover:bg-primary-700 disabled:bg-primary/50 disabled:cursor-not-allowed flex items-center justify-center"
    >
      {isLoading ? (
        <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      ) : (
        buttonText
      )}
    </button>
  </div>
);

const priorityColors: Record<Priority, string> = {
  [Priority.HIGH]: 'bg-danger/10 text-danger',
  [Priority.MEDIUM]: 'bg-warning/10 text-warning',
  [Priority.LOW]: 'bg-gray-500/10 text-gray-600 dark:text-gray-300',
};

const QueryDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { getQueryById, updateQueryStatus, addHistoryToQuery, updateQueryCategory } = useQueries();
  
  // FIX: Removed local state for query. Data is now derived directly from context on every render.
  // This ensures the UI is always in sync with the central state.
  const query = id ? getQueryById(id) : undefined;
  
  const [note, setNote] = useState('');
  const [geminiResult, setGeminiResult] = useState<{title: string, content: string, sources?: GroundingChunk[]} | null>(null);
  const [isLoading, setIsLoading] = useState<Record<string, boolean>>({});

  const handleGeminiAction = async (actionName: string, actionFn: () => Promise<any>) => {
    if (!query) return;
    setIsLoading(prev => ({ ...prev, [actionName]: true }));
    setGeminiResult(null);
    try {
        const result = await actionFn();
        if (actionName === 'recategorize') {
            const newCategory = result.category as Category;
            if (Object.values(Category).includes(newCategory) && query.category !== newCategory) {
               updateQueryCategory(query.id, newCategory);
               // UI now updates automatically as the context state changes. No need for setQuery.
               setGeminiResult({ title: 'AI Re-categorization', content: `Message category updated to: ${newCategory}` });
            } else {
               setGeminiResult({ title: 'AI Re-categorization', content: `AI suggested category is already set or invalid: ${result.category}` });
            }
        } else if (actionName === 'search') {
            setGeminiResult({ title: 'Search with Google', content: result.text, sources: result.groundingChunks });
        }
        else {
           const titles: Record<string, string> = {
                summarize: 'AI Summary',
                draftReply: 'AI Draft Reply',
                deepDive: 'AI Deep Dive Analysis',
           };
           setGeminiResult({ title: titles[actionName], content: result });
        }
    } catch (e) {
        setGeminiResult({ title: `Error: ${actionName}`, content: 'An error occurred while processing the request.' });
    }
    setIsLoading(prev => ({ ...prev, [actionName]: false }));
  };

  if (!query) {
    return <div>Query not found.</div>;
  }

  // Define which categories allow status editing
  const isStatusEditable = [
    Category.COMPLAINT,
    Category.QUESTION,
    Category.BUG_REPORT,
    Category.REQUEST
  ].includes(query.category);

  const handleStatusChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const newStatus = e.target.value as Status;
    // This function updates the context, which triggers a re-render with the new data.
    updateQueryStatus(query.id, newStatus);
  };
  
  const handleAddNote = () => {
    if (note.trim()) {
        // This function updates the context, which triggers a re-render with the new data.
        addHistoryToQuery(query.id, `Note added: "${note}"`, 'Current User');
        setNote('');
    }
  };


  return (
    <div className="space-y-6">
        <button onClick={() => navigate('/dashboard')} className="flex items-center text-sm font-medium text-primary hover:underline">
            <Icon name="arrow-left" className="w-4 h-4 mr-2" />
            Back to Dashboard
        </button>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Query Details & History */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Query Details Card */}
            <div className="bg-white dark:bg-dark p-6 rounded-lg shadow">
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-2xl font-bold text-gray-800 dark:text-white">{query.category}</h2>
                  <p className="text-sm text-gray-500 dark:text-gray-400">from {query.sender} via {query.channel}</p>
                </div>
                <select 
                    value={query.status} 
                    onChange={handleStatusChange} 
                    disabled={!isStatusEditable}
                    className="p-2 border rounded-lg bg-light text-gray-900 dark:bg-gray-100 dark:text-gray-900 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary text-sm disabled:opacity-70 disabled:cursor-not-allowed"
                    title={isStatusEditable ? "Change status" : "Status cannot be changed for this category"}
                >
                    {Object.values(Status).map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <p className="mt-4 text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{query.msg}</p>
              <div className="mt-4 pt-4 border-t dark:border-gray-700 flex space-x-6 text-sm items-center">
                <div className="flex items-center">
                  <strong className="text-gray-600 dark:text-gray-400">Priority:</strong>
                  <span className={`ml-2 px-2.5 py-1 text-xs font-semibold rounded-full ${priorityColors[query.priority]}`}>
                    {query.priority}
                  </span>
                </div>
                <p><strong>Assigned to:</strong> <span className="font-semibold text-gray-800 dark:text-gray-200">{query.team}</span></p>
              </div>
            </div>

            {/* History Timeline */}
            <div className="bg-white dark:bg-dark p-6 rounded-lg shadow">
                <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">History</h3>
                <div className="relative border-l-2 border-gray-200 dark:border-gray-700 ml-3">
                    {query.history.map((entry, index) => (
                        <div key={index} className="mb-6 ml-6">
                            <span className="absolute flex items-center justify-center w-6 h-6 bg-primary/10 rounded-full -left-3 ring-8 ring-white dark:ring-dark">
                               <Icon name="sparkles" className="w-3 h-3 text-primary" />
                            </span>
                            <h4 className="flex items-center mb-1 text-base font-semibold text-gray-900 dark:text-white">{entry.action}</h4>
                            <time className="block mb-2 text-xs font-normal leading-none text-gray-400 dark:text-gray-500">{new Date(entry.timestamp).toLocaleString()}</time>
                            {entry.agent && <p className="text-sm font-normal text-gray-500 dark:text-gray-400">By: {entry.agent}</p>}
                        </div>
                    ))}
                </div>
            </div>
            
            {/* Add Note Card */}
            <div className="bg-white dark:bg-dark p-6 rounded-lg shadow">
              <h3 className="text-lg font-bold mb-4 text-gray-800 dark:text-white">Add a Note</h3>
              <textarea 
                value={note}
                onChange={(e) => setNote(e.target.value)}
                className="w-full p-2 border rounded-lg bg-light text-gray-900 dark:bg-gray-100 dark:text-gray-900 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary"
                rows={3}
                placeholder="Type your internal note here..."
              ></textarea>
              <button onClick={handleAddNote} className="mt-2 font-semibold py-2 px-4 rounded-lg bg-primary text-white hover:bg-primary-700">Add Note</button>
            </div>
          </div>

          {/* Right Column: Gemini Actions */}
          <div className="space-y-6">
              <div className="bg-white dark:bg-dark p-6 rounded-lg shadow space-y-4">
                <h3 className="text-lg font-bold text-center mb-2 text-gray-800 dark:text-white">Gemini AI Assistant</h3>
                <GeminiActionCard title="Quick Summary" description="Get a concise summary." icon="sparkles" buttonText="Summarize" action={() => handleGeminiAction('summarize', () => summarizeWithPro(query.msg))} isLoading={isLoading['summarize']} />
                <GeminiActionCard title="Draft Reply" description="Generate a helpful reply." icon="bolt" buttonText="Draft Reply" action={() => handleGeminiAction('draftReply', () => draftReplyWithLite(query.msg))} isLoading={isLoading['draftReply']} />
                <GeminiActionCard title="Search Google" description="Get up-to-date info." icon="google" buttonText="Search" action={() => handleGeminiAction('search', () => searchWithGrounding(query.msg))} isLoading={isLoading['search']} />
                <GeminiActionCard title="Deep Dive" description="Perform complex analysis." icon="brain" buttonText="Analyze" action={() => handleGeminiAction('deepDive', () => deepDiveWithPro(query.msg))} isLoading={isLoading['deepDive']} />
                <GeminiActionCard title="Re-categorize" description="Let AI find the best category." icon="tag" buttonText="Re-categorize" action={() => handleGeminiAction('recategorize', () => recategorizeWithAI(query.msg))} isLoading={isLoading['recategorize']} />
              </div>

              {geminiResult && (
                <div className="bg-white dark:bg-dark p-6 rounded-lg shadow animate-fade-in">
                  <h3 className="text-lg font-bold mb-2 text-gray-800 dark:text-white">{geminiResult.title}</h3>
                  <div className="text-gray-700 dark:text-gray-300 whitespace-pre-wrap text-sm">{geminiResult.content}</div>
                  {geminiResult.sources && geminiResult.sources.length > 0 && (
                    <div className="mt-4">
                        <h4 className="font-semibold text-gray-800 dark:text-white">Sources:</h4>
                        <ul className="list-disc list-inside text-sm">
                            {geminiResult.sources.map((source, index) => (
                                <li key={index}>
                                    <a href={source.web?.uri} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">{source.web?.title}</a>
                                </li>
                            ))}
                        </ul>
                    </div>
                  )}
                </div>
              )}
          </div>
        </div>
    </div>
  );
};

export default QueryDetailPage;