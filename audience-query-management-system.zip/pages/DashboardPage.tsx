import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQueries } from '../context/QueryContext';
import { Query, Status, Category, Priority, Team } from '../types';
import Icon from '../components/Icon';

const statusColors: Record<Status, string> = {
  [Status.NEW]: 'bg-primary/10 text-primary',
  [Status.ASSIGNED]: 'bg-gray-500/10 text-gray-600 dark:text-gray-300',
  [Status.IN_PROGRESS]: 'bg-warning/10 text-warning',
  [Status.RESOLVED]: 'bg-success/10 text-success',
  [Status.CLOSED]: 'bg-gray-200 text-gray-500 dark:bg-gray-700 dark:text-gray-400',
};

const priorityColors: Record<Priority, string> = {
  [Priority.HIGH]: 'bg-danger/10 text-danger',
  [Priority.MEDIUM]: 'bg-warning/10 text-warning',
  [Priority.LOW]: 'bg-gray-500/10 text-gray-600 dark:text-gray-300',
};

const QUERIES_PER_PAGE = 10;

const DashboardPage: React.FC = () => {
  const { queries } = useQueries();
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [filters, setFilters] = useState({
    status: 'All',
    category: 'All',
    priority: 'All',
    team: 'All',
  });

  const handleFilterChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
    setCurrentPage(1);
  };
  
  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchTerm(e.target.value);
    setCurrentPage(1);
  }

  const filteredQueries = useMemo(() => {
    return queries.filter(query => {
      const searchMatch = query.msg.toLowerCase().includes(searchTerm.toLowerCase()) || query.sender.toLowerCase().includes(searchTerm.toLowerCase());
      const statusMatch = filters.status === 'All' || query.status === filters.status;
      const categoryMatch = filters.category === 'All' || query.category === filters.category;
      const priorityMatch = filters.priority === 'All' || query.priority === filters.priority;
      const teamMatch = filters.team === 'All' || query.team === filters.team;
      return searchMatch && statusMatch && categoryMatch && priorityMatch && teamMatch;
    });
  }, [queries, searchTerm, filters]);

  const paginatedQueries = useMemo(() => {
    const startIndex = (currentPage - 1) * QUERIES_PER_PAGE;
    return filteredQueries.slice(startIndex, startIndex + QUERIES_PER_PAGE);
  }, [filteredQueries, currentPage]);
  
  const totalPages = Math.ceil(filteredQueries.length / QUERIES_PER_PAGE);

  return (
    <div className="bg-white dark:bg-dark rounded-lg shadow">
        {/* Card Header with Filters */}
        <div className="p-4 border-b dark:border-gray-700/50">
           <h3 className="text-lg font-semibold text-gray-800 dark:text-white mb-4">Filters</h3>
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <input type="text" placeholder="Search..." name="search" value={searchTerm} onChange={handleSearchChange} className="w-full px-3 py-2 text-sm text-gray-900 border rounded-lg bg-light dark:text-gray-900 dark:bg-gray-100 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary" />
              <select name="status" value={filters.status} onChange={handleFilterChange} className="w-full px-3 py-2 text-sm text-gray-900 border rounded-lg bg-light dark:text-gray-900 dark:bg-gray-100 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="All">All Statuses</option>
                {Object.values(Status).map(s => <option key={s} value={s}>{s}</option>)}
              </select>
              <select name="category" value={filters.category} onChange={handleFilterChange} className="w-full px-3 py-2 text-sm text-gray-900 border rounded-lg bg-light dark:text-gray-900 dark:bg-gray-100 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="All">All Categories</option>
                {Object.values(Category).map(c => <option key={c} value={c}>{c}</option>)}
              </select>
              <select name="priority" value={filters.priority} onChange={handleFilterChange} className="w-full px-3 py-2 text-sm text-gray-900 border rounded-lg bg-light dark:text-gray-900 dark:bg-gray-100 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="All">All Priorities</option>
                {Object.values(Priority).map(p => <option key={p} value={p}>{p}</option>)}
              </select>
              <select name="team" value={filters.team} onChange={handleFilterChange} className="w-full px-3 py-2 text-sm text-gray-900 border rounded-lg bg-light dark:text-gray-900 dark:bg-gray-100 dark:border-gray-600 focus:outline-none focus:ring-2 focus:ring-primary">
                <option value="All">All Teams</option>
                {Object.values(Team).map(t => <option key={t} value={t}>{t}</option>)}
              </select>
            </div>
        </div>

      {/* Query List Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left text-gray-600 dark:text-gray-400">
          <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700/50 dark:text-gray-400">
            <tr>
              <th scope="col" className="px-6 py-3">Sender</th>
              <th scope="col" className="px-6 py-3">Message Preview</th>
              <th scope="col" className="px-6 py-3">Priority</th>
              <th scope="col" className="px-6 py-3">Team</th>
              <th scope="col" className="px-6 py-3">Status</th>
            </tr>
          </thead>
          <tbody>
            {paginatedQueries.map(query => (
              <tr key={query.id} 
                  onClick={() => navigate(`/query/${query.id}`)}
                  className="cursor-pointer bg-white dark:bg-dark border-b dark:border-gray-700/50 hover:bg-gray-50 dark:hover:bg-gray-800/50">
                <td className="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white flex items-center">
                  <img src={query.senderAvatar} alt={query.sender} className="w-8 h-8 rounded-full mr-3" />
                  {query.sender}
                </td>
                <td className="px-6 py-4 max-w-sm truncate">{query.msg}</td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${priorityColors[query.priority]}`}>
                    {query.priority}
                  </span>
                </td>
                <td className="px-6 py-4">{query.team}</td>
                <td className="px-6 py-4">
                  <span className={`px-2.5 py-1 text-xs font-semibold rounded-full ${statusColors[query.status]}`}>
                    {query.status}
                  </span>
                </td>
              </tr>
            ))}
             {paginatedQueries.length === 0 && (
              <tr>
                  <td colSpan={5} className="text-center py-10 text-gray-500 dark:text-gray-400">
                      No queries match the current filters.
                  </td>
              </tr>
             )}
          </tbody>
        </table>
      </div>

      {totalPages > 1 && (
          <div className="p-4 border-t dark:border-gray-700/50 flex justify-between items-center text-sm text-gray-600 dark:text-gray-400">
              <span>
                  Showing <strong>{paginatedQueries.length}</strong> of <strong>{filteredQueries.length}</strong> results
              </span>
              <div className="space-x-2">
                  <button onClick={() => setCurrentPage(p => Math.max(1, p - 1))} disabled={currentPage === 1} className="px-4 py-2 text-sm font-medium border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100 dark:hover:bg-gray-700">
                      Previous
                  </button>
                  <button onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))} disabled={currentPage === totalPages} className="px-4 py-2 text-sm font-medium border rounded-lg disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-100 dark:hover:bg-gray-700">
                      Next
                  </button>
              </div>
          </div>
      )}
    </div>
  );
};

export default DashboardPage;