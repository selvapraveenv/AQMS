
import React, { useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import LoginPage from './pages/LoginPage';
import BrandOnboardingPage from './pages/BrandOnboardingPage';
import DashboardPage from './pages/DashboardPage';
import QueryDetailPage from './pages/QueryDetailPage';
import AnalyticsPage from './pages/AnalyticsPage';
import TeamsPage from './pages/TeamsPage';
import MainLayout from './components/MainLayout';
import { QueryProvider } from './context/QueryContext';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [selectedBrand, setSelectedBrand] = useState<string | null>(null);

  const handleLogin = () => {
    setIsAuthenticated(true);
  };

  const handleBrandSelect = (brandName: string) => {
    setSelectedBrand(brandName);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setSelectedBrand(null);
  }

  return (
    <QueryProvider>
      <HashRouter>
        <Routes>
          <Route path="/login" element={isAuthenticated ? <Navigate to="/onboarding" /> : <LoginPage onLogin={handleLogin} />} />
          <Route path="/onboarding" element={!isAuthenticated ? <Navigate to="/login" /> : <BrandOnboardingPage onBrandConnected={handleBrandSelect} />} />
          
          <Route 
            path="/*"
            element={
              isAuthenticated && selectedBrand ? (
                <MainLayout brandName={selectedBrand} onLogout={handleLogout}>
                  <Routes>
                    <Route path="/dashboard" element={<DashboardPage />} />
                    <Route path="/query/:id" element={<QueryDetailPage />} />
                    <Route path="/analytics" element={<AnalyticsPage />} />
                    <Route path="/teams" element={<TeamsPage />} />
                    <Route path="*" element={<Navigate to="/dashboard" />} />
                  </Routes>
                </MainLayout>
              ) : (
                <Navigate to={isAuthenticated ? "/onboarding" : "/login"} />
              )
            }
          />
        </Routes>
      </HashRouter>
    </QueryProvider>
  );
};

export default App;