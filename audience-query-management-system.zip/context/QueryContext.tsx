import React, { createContext, useContext, useState, ReactNode, useCallback } from 'react';
import { Query, Status } from '../types';
import { getInitialQueries } from '../data/mockData';

interface QueryContextType {
  queries: Query[];
  getQueries: () => Query[];
  getQueryById: (id: string) => Query | undefined;
  updateQueryStatus: (id: string, status: Status) => void;
  addHistoryToQuery: (id: string, action: string, agent?: string) => void;
  updateQueryCategory: (id: string, category: Query['category']) => void;
}

const QueryContext = createContext<QueryContextType | undefined>(undefined);

export const QueryProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [queries, setQueries] = useState<Query[]>(getInitialQueries());

  const getQueries = useCallback(() => {
    return queries;
  }, [queries]);

  const getQueryById = useCallback((id: string) => {
    return queries.find(q => q.id === id);
  }, [queries]);

  const updateQueryStatus = (id: string, status: Status) => {
    const action = `Status changed to ${status}`;
    const agent = 'Current User';
    setQueries(prevQueries =>
      prevQueries.map(q =>
        q.id === id
          ? {
              ...q,
              status: status, // Update status
              history: [...q.history, { timestamp: new Date().toISOString(), action, agent }], // Add history entry in the same update
            }
          : q
      )
    );
  };
  
  const updateQueryCategory = (id: string, category: Query['category']) => {
    const action = `Category changed to ${category} by AI`;
    const agent = 'Gemini';
    setQueries(prevQueries =>
      prevQueries.map(q =>
        q.id === id
          ? {
              ...q,
              category,
              history: [...q.history, { timestamp: new Date().toISOString(), action, agent }],
            }
          : q
      )
    );
  };

  const addHistoryToQuery = (id: string, action: string, agent?: string) => {
    setQueries(prevQueries =>
      prevQueries.map(q =>
        q.id === id
          ? {
              ...q,
              history: [...q.history, { timestamp: new Date().toISOString(), action, agent }],
            }
          : q
      )
    );
  };


  return (
    <QueryContext.Provider value={{ queries, getQueries, getQueryById, updateQueryStatus, addHistoryToQuery, updateQueryCategory }}>
      {children}
    </QueryContext.Provider>
  );
};

export const useQueries = (): QueryContextType => {
  const context = useContext(QueryContext);
  if (!context) {
    throw new Error('useQueries must be used within a QueryProvider');
  }
  return context;
};